package Bean;

public class user {
    private String riqi;
    private String guanjianzi;
    private String zongjie;
    private String tianshu;
    private String chixutianshu;
    public String getRiqi() {
        return riqi;
    }
    public void setRiqi(String riqi) {
        this.riqi = riqi;
    }
    public String getGuanjianzi() {
        return guanjianzi;
    }
    public void setGuanjianzi(String guanjianzi) {
        this.guanjianzi = guanjianzi;
    }
    public String getZongjie() {
        return zongjie;
    }
    public void setZongjie(String zongjie) {
        this.zongjie = zongjie;
    }
    public String getTianshu() {
        return tianshu;
    }
    public void setTianshu(String tianshu) {
        this.tianshu = tianshu;
    }
    public String getChixutianshu() {
        return chixutianshu;
    }
    public void setChixutianshu(String chixutianshu) {
        this.chixutianshu = chixutianshu;
    }
    public user(String riqi, String guanjianzi, String zongjie, String tianshu, String chixutianshu) {
        super();
        this.riqi = riqi;
        this.guanjianzi = guanjianzi;
        this.zongjie = zongjie;
        this.tianshu = tianshu;
        this.chixutianshu = chixutianshu;
    }
    public user() {
        super();
    }



}

