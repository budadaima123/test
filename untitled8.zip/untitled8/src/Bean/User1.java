package Bean;

public class User1 {
    private String idea;
    private String mudi;
    private String type;
    private String shijian;
    private String didian;
    private String duixiang;
    private String neirong;
    private String anpai;
    public String getIdea() {
        return idea;
    }
    public void setIdea(String idea) {
        this.idea = idea;
    }
    public String getMudi() {
        return mudi;
    }
    public void setMudi(String mudi) {
        this.mudi = mudi;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public String getDidian() {
        return didian;
    }
    public void setDidian(String didian) {
        this.didian = didian;
    }
    public String getDuixiang() {
        return duixiang;
    }
    public void setDuixiang(String duixiang) {
        this.duixiang = duixiang;
    }
    public String getNeirong() {
        return neirong;
    }
    public void setNeirong(String neirong) {
        this.neirong = neirong;
    }
    public String getAnpai() {
        return anpai;
    }
    public void setAnpai(String anpai) {
        this.anpai = anpai;
    }

    public String getShijian() {
        return shijian;
    }
    public void setShijian(String shijian) {
        this.shijian = shijian;
    }
    @Override
    public String toString() {
        return "User [idea=" + idea + ", mudi=" + mudi + ", type=" + type + ", didian=" + didian + ", duixiang="
                + duixiang + ", neirong=" + neirong + ", anpai=" + anpai + "]";
    }


}
