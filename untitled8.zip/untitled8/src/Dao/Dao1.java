package Dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import Bean.User1;
import util.DBUtil1;
public class Dao1 {
    private static String stidea;
    public static boolean delete() {
        Connection conn = DBUtil1.getConn();
        String idea = new String(stidea);
        int a = 0;
        boolean flag = false;
        try {
            String sql = "delete from shetuan where idea = '" + idea + "'";
            PreparedStatement ps = conn.prepareStatement(sql);
            a = ps.executeUpdate();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            System.out.println("删除失败！");
            e.printStackTrace();
        }

        if(a>0) {
            flag = true;
        }

        return flag;

    }

    public static List<User1> select(User1 user2) {
        Connection conn = DBUtil1.getConn();

        String sql = "select * from shetuan where 1=1";

        String idea = user2.getIdea();
        String type = user2.getType();
        String shijian = user2.getShijian();
        String didian = user2.getDidian();

        List<String> strs = new ArrayList<String>();

        if(idea != null && !idea.equals("")) {
            stidea = new String(idea);
            sql = sql + " and idea=?";
            strs.add(idea);
        }
        if(type != null && !type.equals("")) {
            sql = sql + " and type like ?";
            type = "%" + type + "%";
            strs.add(type);
        }
        if(shijian != null && !shijian.equals("")) {
            sql = sql + " and shijian like ?";
            shijian = "%" + shijian + "%";
            strs.add(shijian);
        }
        if(didian != null && !didian.equals("")) {
            sql = sql + " and didian like ?";
            didian = "%" + didian + "%";
            strs.add(didian);
        }
        //sql += " order by id desc";
        //System.out.println(sql);
        List<User1> list = new ArrayList<User1>();
        try {
            //String sql = "select * from tb_user where username=?";
            PreparedStatement ps = conn.prepareStatement(sql);
            //ps.setString(1, username);
            for(int i=0; i<strs.size(); i++) {
                ps.setString(i+1, strs.get(i));
            }
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                User1 user = new User1();
                user.setIdea(rs.getString("idea"));
                user.setMudi(rs.getString("mudi"));
                user.setType(rs.getString("type"));
                user.setShijian(rs.getString("shijian"));
                user.setDidian(rs.getString("didian"));
                user.setDuixiang(rs.getString("duixiang"));
                user.setNeirong(rs.getString("neirong"));
                user.setAnpai(rs.getString("anpai"));
                list.add(user);
            }
            rs.close();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        return list;
    }

    public static boolean add(User1 user) {
        Connection conn = DBUtil1.getConn();
        int a = 0;
        try {

            String idea = user.getIdea();
            String mudi = user.getMudi();
            String type = user.getType();
            String shijian = user.getShijian();
            String didian = user.getDidian();
            String neirong = user.getNeirong();
            String anpai = user.getAnpai();
            String duixiang = user.getDuixiang();

            String sql="insert into shetuan (idea, mudi, type, shijian, didian,neirong,anpai,duixiang) values (?,?,?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, idea);
            ps.setString(2, mudi);
            ps.setString(3, type);
            ps.setString(4, shijian);
            ps.setString(5, didian);
            ps.setString(6, neirong);
            ps.setString(7, anpai);
            ps.setString(8, duixiang);
            a = ps.executeUpdate();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(a>0) {
            return true;
        } else {
            return false;
        }

    }


    public static boolean update(User1 user) {
        Connection conn = DBUtil1.getConn();
        //String idea = user.getIdea();

        String idea = new String(stidea);
        //System.out.println(idea);
        String mudi = user.getMudi();
        String type = user.getType();
        String shijian = user.getShijian();
        String didian = user.getDidian();
        String neirong = user.getNeirong();
        String anpai = user.getAnpai();
        String duixiang = user.getDuixiang();

        String sql = "update shetuan set";
        String sql2 = " where idea='"+idea+"'";
        List<String> strs = new ArrayList<String>();

        if(mudi != null && !mudi.equals("")) {
            sql = sql + " mudi=?,";
            strs.add(mudi);
        }
        if(type != null && !type.equals("")) {
            sql = sql + " type=?,";
            strs.add(type);
        }
        if(shijian != null && !shijian.equals("")) {
            sql = sql + " shijian=?,";
            strs.add(shijian);
        }
        if(didian != null && !didian.equals("")) {
            sql = sql + " didian=?,";
            strs.add(didian);
        }
        if(neirong != null && !neirong.equals("")) {
            sql = sql + " neirong=?,";
            strs.add(neirong);
        }
        if(anpai != null && !anpai.equals("")) {
            sql = sql + " anpai=?,";
            strs.add(anpai);
        }
        if(duixiang != null && !duixiang.equals("")) {
            sql = sql + " duixiang=?,";
            strs.add(duixiang);
        }

        sql = sql.substring(0,sql.length()-1);

        sql += sql2;
        //System.out.println(sql);
        int a = 0;
        boolean flag = false;
        try {
            //String sql="update tb_user set usernumber='"+usernumber+"' where username='"+username+"' ";
            PreparedStatement ps = conn.prepareStatement(sql);
            for(int i=0; i<strs.size(); i++) {
                ps.setString(i+1, strs.get(i));
            }
            a = ps.executeUpdate();
            ps.close();
            conn.close();

        } catch (SQLException e) {
            e.printStackTrace();
        }

        if(a>0) {
            flag = true;
        }
        return flag;
    }
}
