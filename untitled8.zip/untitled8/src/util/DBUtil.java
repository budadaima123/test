package util;
import java.sql.*;
public class DBUtil {
    private static Connection connection;
    private static String url="jdbc:mysql://localhost:3306/runnob?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static String user="root";
    private static String pass="Wjtssywds123";
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        }catch(ClassNotFoundException e){
            e.printStackTrace();
        }
    }
    public static Connection getConnection() {
        try {
            connection=DriverManager.getConnection(url,user,pass);
        }catch(SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    public static void release(Connection connection,Statement statement,ResultSet resultSet) {
        try {
            if(connection!=null) {
                connection.close();
            }
            if(statement!=null) {
                statement.close();
            }
            if(resultSet!=null) {
                resultSet.close();
            }
        }
        catch(SQLException e) {
            e.printStackTrace();
        }
    }
}
