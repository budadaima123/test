package util;
import java.sql.*;
public class DBUtil1 {
    static Connection conn = null;
    //连接数据库，返回Connection conn;
    public static Connection getConn () {
        String driverClassName = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://localhost:3306/runnob?useSSL=false";
        String username = "root";
        String password = "Wjtssywds123";

        try {
            Class.forName(driverClassName);
            conn = DriverManager.getConnection(url, username, password);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;

    }
}
