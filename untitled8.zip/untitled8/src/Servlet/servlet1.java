package Servlet;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Dao.Dao1;
import Bean.User1;
/**
 * Servlet implementation class servlet
 */
@WebServlet("/servlet2")
public class servlet1 extends HttpServlet {
    private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub

        request.setCharacterEncoding("utf-8");
        String method = request.getParameter("method");
        if (method.equals("addUser")) {
            addUser(request, response);
        } else if(method.equals("select")) {
            select(request, response);
        } else if(method.equals("deleteDemo")) {
            deleteDemo(request, response);
        } else if(method.equals("updateDemo")) {
            updateDemo(request, response);
        } else if(method.equals("showDemo")) {
            showDemo(request, response);
        } else if(method.equals("selectDemo")) {
            selectDemo(request, response);
        }
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

    private void addUser(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // 设置相应的文本类型
        request.setCharacterEncoding("utf-8");
        // 设置响应类型,并防止中文乱码
        response.setContentType("text/html;charset=utf-8");

        String idea = request.getParameter("idea");
        String mudi = request.getParameter("mudi");
        String type = request.getParameter("type");
        String shijian = request.getParameter("shijian");
        String didian = request.getParameter("didian");
        String neirong = request.getParameter("neirong");
        String anpai = request.getParameter("anpai");
        String[] duixiangs = request.getParameterValues("duixiang");
        String duixiang = "";
        if(duixiangs != null){
            for(int i=0; i<duixiangs.length; i++){
                duixiang += duixiangs[i];
            }
        }

        User1 user = new User1();
        user.setIdea(idea);
        user.setMudi(mudi);
        user.setType(type);
        user.setShijian(shijian);
        user.setDidian(didian);
        user.setDuixiang(duixiang);
        user.setNeirong(neirong);
        user.setAnpai(anpai);
        if(Dao1.add(user)) {
            request.setAttribute("message", "添加成功");
            response.sendRedirect("menu.jsp");
        } else {
            request.setAttribute("message", "添加失败");
            request.getRequestDispatcher("add.jsp").forward(request,response);
        }
    }

    private void select(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        // 设置相应的文本类型
        response.setContentType("text/html;charset=utf-8");// 设置响应类型,并防止中文乱码

        String idea = request.getParameter("idea3");
        String f = request.getParameter("f");
        System.out.println(f);

        User1 user = new User1();
        user.setIdea(idea);

        List<User1> list = Dao1.select(user);
        request.setAttribute("list", list);
        if(f.equals("1")) {
            request.getRequestDispatcher("/delete.jsp").forward(request, response);
        } else if(f.equals("2")) {
            request.getRequestDispatcher("/update.jsp").forward(request, response);
        }
    }

    private void deleteDemo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        // 设置相应的文本类型
        response.setContentType("text/html;charset=utf-8");// 设置响应类型,并防止中文乱码

        if(Dao1.delete()) {
            response.sendRedirect("menu.jsp");
        } else {
            request.setAttribute("message", "删除失败");
            request.getRequestDispatcher("delete.jsp").forward(request,response);
        }
    }


    private void updateDemo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        // 设置相应的文本类型
        response.setContentType("text/html;charset=utf-8");// 设置响应类型,并防止中文乱码

        //String idea = request.getParameter("idea3");
        String mudi = request.getParameter("mudi3");
        String type = request.getParameter("type3");
        String shijian = request.getParameter("shijian3");
        String didian = request.getParameter("didian3");
        String neirong = request.getParameter("neirong3");
        String anpai = request.getParameter("anpai3");
        String duixiang = request.getParameter("duixiang3");

        User1 user = new User1();
        //user.setIdea(idea);
        user.setMudi(mudi);
        user.setType(type);
        user.setShijian(shijian);
        user.setDidian(didian);
        user.setDuixiang(duixiang);
        user.setNeirong(neirong);
        user.setAnpai(anpai);

        if(Dao1.update(user)) {
            response.sendRedirect("menu.jsp");
        } else {
            request.setAttribute("message", "该活动不存在");
            request.getRequestDispatcher("update.jsp").forward(request,response);
        }
    }

    private void showDemo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        // 设置相应的文本类型
        response.setContentType("text/html;charset=utf-8");// 设置响应类型,并防止中文乱码

        User1 user = new User1();
        String idea = request.getParameter("idea");
        user.setIdea(idea);

        List<User1> list = Dao1.select(user);
        request.setAttribute("list", list);

        //request.getRequestDispatcher("/selectshow.jsp").forward(request, response);
        request.getRequestDispatcher("/showall.jsp").forward(request, response);
    }

    private void selectDemo(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf-8");
        // 设置相应的文本类型
        response.setContentType("text/html;charset=utf-8");// 设置响应类型,并防止中文乱码

        String idea = request.getParameter("idea2");
        String shijian = request.getParameter("shijian2");
        String type = request.getParameter("type2");
        String didian = request.getParameter("didian2");
        User1 user = new User1();
        user.setIdea(idea);
        user.setShijian(shijian);
        user.setType(type);
        user.setDidian(didian);
        List<User1> list = Dao1.select(user);
        request.setAttribute("list", list);

        request.getRequestDispatcher("/selectshow.jsp").forward(request, response);
    }

}
